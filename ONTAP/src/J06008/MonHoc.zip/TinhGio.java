// TinhGio.java
package J06008;

public class TinhGio {
    private MonHoc mh;
    private GiangVien gv;
    private double tongio;

    public TinhGio(MonHoc mh, GiangVien gv, double tongio) {
        this.mh = mh;
        this.gv = gv;
        this.tongio = tongio;
    }

    public GiangVien getGv() {
        return gv;
    }

    public MonHoc getMh() {
        return mh;
    }

    public double getTongio() {
        return tongio;
    }
}