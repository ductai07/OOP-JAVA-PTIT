package J06001;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        List<SanPham> sp_list = new ArrayList<>();
        for(int i = 1; i <= t; i++){
            String masp = sc.nextLine();
            String tensp = sc.nextLine();
            long dongia1 = Long.parseLong(sc.nextLine());
            long dongia2 = Long.parseLong(sc.nextLine());
            SanPham a = new SanPham(masp, tensp, dongia1, dongia2);
            sp_list.add(a);
        }
        int q = Integer.parseInt(sc.nextLine());
        List<HoaDon> hd_list = new ArrayList<>();
        for(int i = 1; i <= q; i++){
            String[] tokens = sc.nextLine().split(" ");
            String tmp = tokens[0];
            String masp = tmp.substring(0, 2);
            int loaisp = Integer.parseInt(tmp.substring(2, 3));
            int soluong = Integer.parseInt(tokens[1]);
            long tongtien = 0;
            long giamgia = 0;
            SanPham res = null;
            for(SanPham sp : sp_list){
                if(masp.equals(sp.getMaloai())){
                    if(loaisp == 1){
                        tongtien = sp.getDongialoai1() * soluong;
                    } else {
                        tongtien = sp.getDongialoai2() * soluong;
                    }
                    if(soluong >= 150) {
                        giamgia = tongtien * 50 / 100;
                    } else if(soluong >= 100) {
                        giamgia = tongtien * 30 / 100;
                    } else if(soluong >= 50) {
                        giamgia = tongtien * 15 / 100;
                    } else {
                        giamgia = 0;
                    }
                    tongtien = tongtien - giamgia;
                    res = sp;
                    break;
                }
            }
            String madon = String.format("%03d", i);
            String mahoadon = tmp + "-" + madon;
            HoaDon a = new HoaDon(mahoadon, res, giamgia, tongtien);
            hd_list.add(a);
        }
        for(HoaDon a : hd_list){
            System.out.println(a);
        }
    }
}