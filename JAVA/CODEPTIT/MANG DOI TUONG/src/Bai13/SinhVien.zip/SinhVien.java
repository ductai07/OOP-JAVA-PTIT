package Bai13;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SinhVien implements Comparable<SinhVien> {
    private String hoTen;
    private Date thoigianBatdau, thoigianKetthuc;
    private long thoigianOnl;

    public SinhVien(String hoTen, String thoigianBatdau, String thoigianKetthuc) throws ParseException {
        this.hoTen = hoTen;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        this.thoigianBatdau = sdf.parse(thoigianBatdau);
        this.thoigianKetthuc = sdf.parse(thoigianKetthuc);
        this.thoigianOnl = (this.thoigianKetthuc.getTime() - this.thoigianBatdau.getTime()) / (60 * 1000);

    }

    public String getHoTen() {
        return hoTen;
    }

    public long getThoigianOnl() {
        return thoigianOnl;
    }

    @Override
    public int compareTo(SinhVien other) {
        if (this.thoigianOnl != other.thoigianOnl) {
            return Long.compare(other.thoigianOnl, this.thoigianOnl);
        }
        return this.hoTen.compareTo(other.hoTen);
    }
    @Override
    public String toString(){
        return hoTen+" "+thoigianOnl;
    }
}