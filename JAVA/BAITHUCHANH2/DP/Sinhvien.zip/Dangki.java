package BAITHUCHANH2.DP;

public class Dangki {
    private String studentId;
    private String size;

    public Dangki(String studentId, String size) {
        this.studentId = studentId;
        this.size = size;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getSize() {
        return size;
    }
}